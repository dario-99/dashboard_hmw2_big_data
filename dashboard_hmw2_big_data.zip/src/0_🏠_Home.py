
"""
    Authors: Dario Di Meo, Leonardo Alberto Anania
    Description: Streamlit dashboard for 2nd homework of the 2022/2023 Big Data cource
"""

# External module
import streamlit as st
import numpy as np

# Python native modules
import json

# Streamlit page config
st.set_page_config(
    layout='wide',
    page_icon='📈',
    page_title='Dashboard Big Data'
)

# Introduction page
st.title("📜🎉 800 anni Federico II")

st.subheader(
    "In questa dashboard inseriremo alcuni grafici relativi ai fondi istanziati dall'unione europea per la Federico II. Nella sidebar si possono trovare i vari grafici disponibili."
)
st.image('assets\Logo.png')